sybilSBML
=========

SBML (Systems Biology Markup Language) integration in sybil
